
import { GoogleGenAI, Type } from "@google/genai";
import { Novel, Character, WorldSetting, TimelineEvent } from "../types";

// 获取 API Key（支持 Vite 环境变量）
const getApiKey = () => {
  const key = process.env.API_KEY || process.env.GEMINI_API_KEY || '';
  // 调试信息
  if (typeof window !== 'undefined') {
    console.log('API Key 检查:', {
      hasApiKey: !!key,
      keyLength: key.length,
      keyPrefix: key ? key.substring(0, 10) + '...' : '无',
      envKeys: {
        API_KEY: !!process.env.API_KEY,
        GEMINI_API_KEY: !!process.env.GEMINI_API_KEY
      }
    });
  }
  return key;
};

const apiKey = getApiKey();
if (!apiKey) {
  console.error('❌ 错误：未找到 Gemini API Key！');
  console.error('请在项目根目录创建 .env.local 文件，并添加：');
  console.error('GEMINI_API_KEY=your_api_key_here');
  console.error('然后重启开发服务器。');
}

const ai = new GoogleGenAI({ apiKey });

// 超时时间：5分钟（300秒）
const API_TIMEOUT_MS = 300000;

// 流式传输回调函数类型
export type StreamChunkCallback = (chunk: string, isComplete: boolean) => void;

// 超时包装函数：为 Promise 添加超时控制
const withTimeout = <T>(promise: Promise<T>, timeoutMs: number = API_TIMEOUT_MS): Promise<T> => {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => {
      setTimeout(() => {
        reject(new Error(`请求超时（${timeoutMs / 1000}秒）。请检查网络连接或稍后重试`));
      }, timeoutMs);
    })
  ]);
};

// 流式传输处理函数：处理流式响应并调用回调
const processStreamResponse = async (
  streamPromise: Promise<AsyncGenerator<any>>,
  onChunk?: StreamChunkCallback,
  timeoutMs: number = API_TIMEOUT_MS
): Promise<string> => {
  let fullText = '';
  
  // 为流式响应添加超时控制
  const stream = await withTimeout(streamPromise, timeoutMs);
  
  // 创建一个超时 Promise
  const timeoutPromise = new Promise<string>((_, reject) => {
    setTimeout(() => {
      reject(new Error(`流式传输超时（${timeoutMs / 1000}秒）。请检查网络连接或稍后重试`));
    }, timeoutMs);
  });
  
  // 使用 Promise.race 来控制流式读取的超时
  const streamProcessing = (async () => {
    const startTime = Date.now();
    for await (const chunk of stream) {
      // 检查是否超时
      if (Date.now() - startTime > timeoutMs) {
        throw new Error(`流式传输超时（${timeoutMs / 1000}秒）。请检查网络连接或稍后重试`);
      }
      
      if (chunk?.text) {
        const chunkText = chunk.text;
        fullText += chunkText;
        if (onChunk) {
          onChunk(chunkText, false);
        }
      }
    }
    
    if (onChunk) {
      onChunk('', true); // 标记完成
    }
    
    return fullText;
  })();
  
  return Promise.race([streamProcessing, timeoutPromise]);
};

// 生成完整大纲和卷结构
export const generateFullOutline = async (
  title: string, 
  genre: string, 
  synopsis: string,
  onChunk?: StreamChunkCallback
) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  try {
    console.log('🚀 开始调用 Gemini API 生成大纲和卷结构...');
    console.log('请求参数:', { title, genre, synopsis: synopsis.substring(0, 50) + '...' });
    
    // 先生成完整大纲文本（使用流式传输）
    const outlinePrompt = `作为一名资深小说家，请为标题为《${title}》的小说创作一份完整的故事大纲。
      类型：${genre}。
      初始创意：${synopsis}。
      请提供多幕结构、关键情节转折，以及从开头到结尾的逻辑发展。`;
    
    let fullOutline: string;
    if (onChunk) {
      // 流式传输模式
      onChunk('📝 正在生成完整大纲...\n\n', false);
      fullOutline = await processStreamResponse(
        ai.models.generateContentStream({
          model: 'gemini-3-pro-preview',
          contents: outlinePrompt,
          config: {
            thinkingConfig: { thinkingBudget: 2000 }
          }
        }),
        (chunk, isComplete) => {
          if (!isComplete && chunk) {
            onChunk(chunk, false);
          }
        }
      );
    } else {
      // 非流式模式（向后兼容）
      const outlineResponse = await withTimeout(ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: outlinePrompt,
        config: {
          thinkingConfig: { thinkingBudget: 2000 }
        }
      }));
      
      if (!outlineResponse || !outlineResponse.text) {
        throw new Error('API 返回空响应');
      }
      fullOutline = outlineResponse.text;
    }
    
    console.log('✅ 完整大纲生成成功');
    
    // 然后生成卷结构（JSON 格式，不使用流式传输）
    const volumesResponse = await withTimeout(ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `基于以下完整大纲，将故事划分为多个卷（通常3-5卷）。
      完整大纲：${fullOutline.substring(0, 2000)}
      
      请为每个卷生成标题和简要描述。仅返回 JSON 数组，每个对象包含：
      - "title"（卷标题）
      - "summary"（卷的简要描述，50-100字）`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING }
            },
            required: ["title", "summary"]
          }
        }
      }
    }));
    
    if (!volumesResponse || !volumesResponse.text) {
      console.warn('⚠️ 卷结构生成失败，使用默认卷');
      return { outline: fullOutline, volumes: null };
    }
    
    let volumesData = null;
    try {
      volumesData = JSON.parse(volumesResponse.text);
      if (!Array.isArray(volumesData)) {
        console.warn('⚠️ 卷数据格式不正确，使用默认卷');
        volumesData = null;
      }
    } catch (e) {
      console.warn('⚠️ 卷数据解析失败，使用默认卷:', e);
      volumesData = null;
    }
    
    return { outline: fullOutline, volumes: volumesData };
  } catch (error: any) {
    console.error('❌ 生成大纲 API 错误详情:', {
      message: error?.message,
      name: error?.name,
      stack: error?.stack,
      fullError: error
    });
    
    // 提供更详细的错误信息
    let errorMsg = '未知错误';
    if (error?.message) {
      errorMsg = error.message;
    } else if (typeof error === 'string') {
      errorMsg = error;
    } else if (error?.toString) {
      errorMsg = error.toString();
    }
    
    // 检查常见错误类型
    if (errorMsg.includes('401') || errorMsg.includes('unauthorized') || errorMsg.includes('API key')) {
      errorMsg = 'API Key 无效或未配置。请检查 .env.local 文件中的 GEMINI_API_KEY';
    } else if (errorMsg.includes('network') || errorMsg.includes('fetch') || errorMsg.includes('CORS') || errorMsg.includes('Failed to fetch')) {
      errorMsg = '网络连接失败。\n\n重要提示：由于应用在浏览器中运行，需要配置浏览器代理：\n1. 确保代理软件（127.0.0.1:7899）正在运行\n2. 在浏览器中配置系统代理，或使用代理扩展\n3. 重启浏览器后重试';
    } else if (errorMsg.includes('timeout')) {
      errorMsg = '请求超时。请检查网络连接或稍后重试';
    } else if (errorMsg.includes('403') || errorMsg.includes('forbidden')) {
      errorMsg = 'API 访问被拒绝。请检查 API Key 权限或配额';
    }
    
    throw new Error(`生成大纲失败: ${errorMsg}`);
  }
};

// 生成单个卷的详细大纲
export const generateVolumeOutline = async (novel: Novel, volumeIndex: number, onChunk?: StreamChunkCallback) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  if (!novel.title || !novel.fullOutline) {
    throw new Error('需要完整的小说标题和大纲');
  }
  
  if (!novel.volumes || volumeIndex >= novel.volumes.length) {
    throw new Error('卷索引无效');
  }
  
  const volume = novel.volumes[volumeIndex];
  
  try {
    console.log(`🚀 开始生成第 ${volumeIndex + 1} 卷的详细大纲...`);
    
    const volumePrompt = `基于以下信息，为《${novel.title}》的第 ${volumeIndex + 1} 卷《${volume.title}》生成详细大纲。
      
      完整小说大纲：${novel.fullOutline.substring(0, 1500)}
      
      本卷信息：
      标题：${volume.title}
      ${volume.summary ? `描述：${volume.summary}` : ''}
      
      角色：${novel.characters.map(c => `${c.name}（${c.role}）`).join('、') || '暂无'}
      
      请生成本卷的详细大纲，包括：
      1. 本卷的主要情节线
      2. 关键事件和转折点
      3. 角色在本卷中的发展
      4. 本卷的起承转合结构
      
      重要：请根据总纲中本卷的内容量，规划本卷的字数和章节数。
      - 分析本卷在总纲中的情节复杂度、事件数量和内容量
      - 估算本卷的合理字数范围（通常每卷15-30万字）
      - 根据字数规划章节数（通常每章1.5-2.5万字）
      - 确保章节数量合理，既能充分展开情节，又不会过于冗长
      
      请在大纲末尾明确标注：
      【字数规划】：XX-XX万字（例如：18-22万字）
      【章节规划】：XX章（例如：12章，必须是具体数字，不要范围）`;
    
    let responseText: string;
    if (onChunk) {
      // 流式传输模式
      onChunk(`📝 正在生成第 ${volumeIndex + 1} 卷《${volume.title}》的详细大纲...\n\n`, false);
      responseText = await processStreamResponse(
        ai.models.generateContentStream({
          model: 'gemini-3-pro-preview',
          contents: volumePrompt,
          config: {
            thinkingConfig: { thinkingBudget: 2000 }
          }
        }),
        (chunk, isComplete) => {
          if (!isComplete && chunk) {
            onChunk(chunk, false);
          }
        }
      );
    } else {
      // 非流式模式（向后兼容）
      const response = await withTimeout(ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: volumePrompt,
        config: {
          thinkingConfig: { thinkingBudget: 2000 }
        }
      }));
      
      if (!response || !response.text) {
        throw new Error('API 返回空响应');
      }
      responseText = response.text;
    }
    
    console.log(`✅ 第 ${volumeIndex + 1} 卷详细大纲生成成功`);
    return responseText;
  } catch (error: any) {
    console.error(`❌ 生成第 ${volumeIndex + 1} 卷大纲错误:`, error);
    throw new Error(`生成卷大纲失败: ${error?.message || error?.toString() || '未知错误'}`);
  }
};

export const generateChapterOutline = async (novel: Novel, volumeIndex: number = 0, chapterCount?: number) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  if (!novel.title) {
    throw new Error('小说标题不能为空');
  }
  
  if (!novel.fullOutline) {
    throw new Error('完整大纲不能为空');
  }
  
  if (!novel.volumes || volumeIndex >= novel.volumes.length) {
    throw new Error('卷索引无效');
  }
  
  const volume = novel.volumes[volumeIndex];
  
  try {
    console.log(`🚀 开始调用 Gemini API 生成第 ${volumeIndex + 1} 卷的章节列表...`);
    console.log('请求参数:', { 
      title: novel.title, 
      genre: novel.genre,
      volumeTitle: volume.title,
      outlineLength: novel.fullOutline.length,
      charactersCount: novel.characters.length
    });
    
    // 限制内容长度以避免请求过大
    const volumeOutlineText = volume.outline ? volume.outline.substring(0, 1500) : '';
    const fullOutlineText = novel.fullOutline.substring(0, 800);
    const volumeSummaryText = volume.summary ? volume.summary.substring(0, 200) : '';
    
    // 从卷大纲中提取字数规划和章节规划
    let wordCountRange: { min: number; max: number } | undefined = undefined;
    let plannedChapterCount: number | undefined = undefined;
    
    if (volume.outline) {
      // 1. 提取字数规划（例如：【字数规划】：18-22万字）
      const wordCountPatterns = [
        /【字数规划】：\s*(\d+)[-~](\d+)\s*万字/,  // 【字数规划】：18-22万字
        /字数规划[：:]\s*(\d+)[-~](\d+)\s*万字/,    // 字数规划：18-22万字
        /【字数规划】：\s*(\d+)\s*万字/,            // 【字数规划】：20万字
        /字数规划[：:]\s*(\d+)\s*万字/              // 字数规划：20万字
      ];
      
      for (const pattern of wordCountPatterns) {
        const match = volume.outline.match(pattern);
        if (match) {
          if (match[2]) {
            // 范围格式
            wordCountRange = {
              min: parseInt(match[1], 10) * 10000,  // 转换为字数
              max: parseInt(match[2], 10) * 10000
            };
            console.log(`📊 从卷大纲中提取到字数规划: ${match[1]}-${match[2]}万字`);
          } else {
            // 单个数字
            const wordCount = parseInt(match[1], 10) * 10000;
            wordCountRange = { min: wordCount, max: wordCount };
            console.log(`📊 从卷大纲中提取到字数规划: ${match[1]}万字`);
          }
          break;
        }
      }
      
      // 2. 提取章节规划（例如：【章节规划】：12章）
      const chapterPatterns = [
        /【章节规划】：\s*(\d+)\s*章/,  // 【章节规划】：12章
        /章节规划[：:]\s*(\d+)\s*章/,    // 章节规划：12章
        /【章节规划】：\s*(\d+)[-~](\d+)\s*章/  // 【章节规划】：10-15章（取中间值）
      ];
      
      for (const pattern of chapterPatterns) {
        const match = volume.outline.match(pattern);
        if (match) {
          if (match[2]) {
            // 范围格式，取中间值
            const min = parseInt(match[1], 10);
            const max = parseInt(match[2], 10);
            plannedChapterCount = Math.floor((min + max) / 2);
            console.log(`📊 从卷大纲中提取到章节规划范围: ${min}-${max}章，使用 ${plannedChapterCount} 章`);
          } else {
            // 单个数字
            plannedChapterCount = parseInt(match[1], 10);
            console.log(`📊 从卷大纲中提取到章节规划: ${plannedChapterCount} 章`);
          }
          break;
        }
      }
      
      // 3. 如果有字数规划但没有章节规划，根据字数计算合理的章节数
      // 假设每章1.5-2.5万字
      if (wordCountRange && !plannedChapterCount) {
        const avgWordsPerChapter = 20000; // 平均每章2万字
        const avgWordCount = (wordCountRange.min + wordCountRange.max) / 2;
        plannedChapterCount = Math.round(avgWordCount / avgWordsPerChapter);
        // 确保章节数在合理范围内（6-30章）
        plannedChapterCount = Math.max(6, Math.min(30, plannedChapterCount));
        console.log(`📊 根据字数规划（${wordCountRange.min/10000}-${wordCountRange.max/10000}万字）计算章节数: ${plannedChapterCount} 章`);
      }
    }
    
    // 优先级：用户指定 > 卷大纲章节规划 > 根据字数规划计算 > AI自动决定
    const finalChapterCount = chapterCount || plannedChapterCount;
    
    if (finalChapterCount) {
      const source = chapterCount ? '用户指定' : (plannedChapterCount ? '卷大纲规划' : '根据字数计算');
      console.log(`📊 最终章节数量: ${finalChapterCount} 章（${source}）`);
    } else {
      console.log(`📊 最终章节数量: AI自动决定`);
    }
    
    // 构建字数规划信息字符串
    let wordCountInfo = '';
    if (wordCountRange) {
      const minWan = wordCountRange.min / 10000;
      const maxWan = wordCountRange.max / 10000;
      if (minWan === maxWan) {
        wordCountInfo = `\n字数规划：${minWan}万字`;
      } else {
        wordCountInfo = `\n字数规划：${minWan}-${maxWan}万字`;
      }
    }
    
    const prompt = `基于以下小说信息，为第 ${volumeIndex + 1} 卷《${volume.title}》生成章节列表：
标题：${novel.title}
类型：${novel.genre}
完整大纲：${fullOutlineText}${novel.fullOutline.length > 800 ? '...' : ''}

本卷信息：
${volumeSummaryText ? `卷描述：${volumeSummaryText}${volume.summary && volume.summary.length > 200 ? '...' : ''}` : ''}
${volumeOutlineText ? `卷详细大纲：${volumeOutlineText}${volume.outline && volume.outline.length > 1500 ? '...' : ''}` : ''}${wordCountInfo}

角色：${novel.characters.slice(0, 5).map(c => `${c.name}（${c.role}）`).join('、') || '暂无'}${novel.characters.length > 5 ? '等' : ''}

${finalChapterCount ? `请为本卷生成 ${finalChapterCount} 个章节。${wordCountRange ? `章节数量已根据卷大纲中的字数规划（${wordCountRange.min/10000}-${wordCountRange.max/10000}万字）和章节规划确定。请确保章节数量与字数规划相匹配（通常每章1.5-2.5万字）。` : '章节数量已根据卷大纲中的规划确定。'}` : `请仔细分析本卷的详细大纲${wordCountRange ? `和字数规划（${wordCountRange.min/10000}-${wordCountRange.max/10000}万字）` : ''}，根据以下原则确定合适的章节数量并生成章节列表：
章节数量应该：
1. ${wordCountRange ? `优先参考卷大纲中的字数规划（${wordCountRange.min/10000}-${wordCountRange.max/10000}万字），根据字数计算合理的章节数（通常每章1.5-2.5万字）` : '优先参考卷大纲中标注的【章节规划】（如果存在）'}
2. 根据卷大纲的内容复杂度合理分配
3. 确保每个章节有足够的内容和情节发展（通常每章1.5-2.5万字）
4. 如果大纲中明确提到了章节数，请参考该数量
5. 如果大纲中没有明确提到，请根据情节结构合理分配（通常每章对应一个主要事件或情节转折点）
6. 章节数量应在合理范围内（建议6-30章）`}

仅返回 JSON 数组，每个对象包含以下键："title"（标题）、"summary"（摘要）、"aiPromptHints"（AI提示）。`;
    
    console.log('📝 生成章节列表提示词长度:', prompt.length);
    
    const response = await withTimeout(ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              summary: { type: Type.STRING },
              aiPromptHints: { type: Type.STRING }
            },
            required: ["title", "summary", "aiPromptHints"]
          }
        }
      }
    }));
    
    console.log('✅ API 调用成功，收到响应');
    
    if (!response || !response.text) {
      throw new Error('API 返回空响应');
    }
    
    console.log('📝 原始响应文本长度:', response.text.length);
    console.log('📝 响应文本预览:', response.text.substring(0, 200));
    
    // 尝试解析 JSON
    let parsedData;
    try {
      parsedData = JSON.parse(response.text);
    } catch (parseError: any) {
      console.error('❌ JSON 解析失败:', {
        error: parseError,
        responseText: response.text.substring(0, 500)
      });
      throw new Error(`JSON 解析失败: ${parseError?.message || '未知错误'}\n响应内容: ${response.text.substring(0, 200)}`);
    }
    
    // 验证解析后的数据
    if (!Array.isArray(parsedData)) {
      console.error('❌ 解析后的数据不是数组:', parsedData);
      throw new Error(`期望数组但收到: ${typeof parsedData}`);
    }
    
    console.log(`✅ 成功解析 ${parsedData.length} 个章节`);
    
    return parsedData;
  } catch (error: any) {
    console.error('❌ 生成章节 API 错误详情:', {
      message: error?.message,
      name: error?.name,
      stack: error?.stack,
      fullError: error
    });
    
    // 提供更详细的错误信息
    let errorMsg = '未知错误';
    if (error?.message) {
      errorMsg = error.message;
    } else if (typeof error === 'string') {
      errorMsg = error;
    } else if (error?.toString) {
      errorMsg = error.toString();
    }
    
    // 检查常见错误类型
    if (errorMsg.includes('401') || errorMsg.includes('unauthorized') || errorMsg.includes('API key')) {
      errorMsg = 'API Key 无效或未配置。请检查 .env.local 文件中的 GEMINI_API_KEY';
    } else if (errorMsg.includes('network') || errorMsg.includes('fetch') || errorMsg.includes('CORS') || errorMsg.includes('Failed to fetch') || errorMsg.includes('ERR_CONNECTION_CLOSED') || errorMsg.includes('ERR_PROXY_CONNECTION_FAILED') || errorMsg.includes('NetworkError')) {
      errorMsg = '网络连接失败。\n\n重要提示：由于应用在浏览器中运行，需要配置浏览器代理：\n1. 确保代理软件（127.0.0.1:7899）正在运行\n2. 在浏览器中配置系统代理，或使用代理扩展\n3. 重启浏览器后重试\n\n如果问题持续存在，可能是请求内容过大导致连接被关闭，请尝试：\n- 简化卷大纲内容\n- 减少章节数量\n- 检查网络连接稳定性';
    } else if (errorMsg.includes('timeout') || errorMsg.includes('Timeout')) {
      errorMsg = '请求超时（5分钟）。请检查网络连接或稍后重试。如果问题持续，可能是请求内容过大，请尝试简化卷大纲内容。';
    } else if (errorMsg.includes('403') || errorMsg.includes('forbidden')) {
      errorMsg = 'API 访问被拒绝。请检查 API Key 权限或配额';
    } else if (errorMsg.includes('JSON') || errorMsg.includes('parse')) {
      errorMsg = `数据解析失败: ${errorMsg}\n\n这可能是 API 返回了非 JSON 格式的数据。请查看浏览器控制台获取更多信息。`;
    }
    
    throw new Error(`生成章节失败: ${errorMsg}`);
  }
};

export const writeChapterContent = async (novel: Novel, chapterIndex: number, volumeIndex: number, onChunk?: StreamChunkCallback) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  try {
    const chapter = novel.volumes[volumeIndex].chapters[chapterIndex];
    const chapterPrompt = `请为小说《${novel.title}》创作一个完整的章节。
      章节标题：${chapter.title}
      情节摘要：${chapter.summary}
      写作提示：${chapter.aiPromptHints}
      
      上下文：
      完整小说简介：${novel.synopsis}
      涉及角色：${novel.characters.map(c => `${c.name}：${c.personality}`).join('；')}
      世界观规则：${novel.worldSettings.map(s => `${s.title}：${s.description}`).join('；')}
      
      请以高文学品质、沉浸式描述和引人入胜的对话来创作。仅输出章节正文内容。`;
    
    let responseText: string;
    if (onChunk) {
      // 流式传输模式
      onChunk(`📝 正在生成章节《${chapter.title}》的内容...\n\n`, false);
      responseText = await processStreamResponse(
        ai.models.generateContentStream({
          model: 'gemini-3-pro-preview',
          contents: chapterPrompt,
          config: {
            thinkingConfig: { thinkingBudget: 4000 }
          }
        }),
        (chunk, isComplete) => {
          if (!isComplete && chunk) {
            onChunk(chunk, false);
          }
        }
      );
    } else {
      // 非流式模式（向后兼容）
      const response = await withTimeout(ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: chapterPrompt,
        config: {
          thinkingConfig: { thinkingBudget: 4000 }
        }
      }));
      
      if (!response || !response.text) {
        throw new Error('API 返回空响应');
      }
      responseText = response.text;
    }
    
    return responseText;
  } catch (error: any) {
    console.error('生成章节内容 API 错误:', error);
    throw new Error(`生成章节内容失败: ${error?.message || error?.toString() || '未知错误'}`);
  }
};

// 生成下一章节内容（考虑前文上下文）
export const writeNextChapterContent = async (
  novel: Novel, 
  currentChapterIndex: number, 
  volumeIndex: number,
  onChunk?: StreamChunkCallback
) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  try {
    const currentChapter = novel.volumes[volumeIndex].chapters[currentChapterIndex];
    const nextChapterIndex = currentChapterIndex + 1;
    
    if (nextChapterIndex >= novel.volumes[volumeIndex].chapters.length) {
      throw new Error('没有下一章节，请先在大纲页面生成章节列表');
    }
    
    const nextChapter = novel.volumes[volumeIndex].chapters[nextChapterIndex];
    const volume = novel.volumes[volumeIndex];
    
    // 获取前文章节上下文：前一章完整内容 + 之前章节的摘要
    const previousChaptersContext: string[] = [];
    
    // 只有前一章（currentChapterIndex - 1）才包含完整内容
    if (currentChapterIndex > 0) {
      const prevChapter = novel.volumes[volumeIndex].chapters[currentChapterIndex - 1];
      previousChaptersContext.push(`第${currentChapterIndex}章《${prevChapter.title}》（完整内容）：\n${prevChapter.content || prevChapter.summary || ''}`);
    }
    
    // 之前的章节（currentChapterIndex - 2及更早）只包含摘要
    if (currentChapterIndex > 1) {
      const earlierChapters = novel.volumes[volumeIndex].chapters
        .slice(Math.max(0, currentChapterIndex - 5), currentChapterIndex - 1) // 最多取前5章（不包含前一章）
        .map((ch, idx) => {
          const chapterNum = Math.max(0, currentChapterIndex - 5) + idx + 1;
          return `第${chapterNum}章《${ch.title}》（摘要）：${ch.summary || '暂无摘要'}`;
        });
      if (earlierChapters.length > 0) {
        previousChaptersContext.unshift(...earlierChapters);
      }
    }
    
    const previousChapters = previousChaptersContext.length > 0 
      ? previousChaptersContext.join('\n\n')
      : '（这是本卷的第一章）';
    
    // 完整的角色信息
    const charactersText = novel.characters.length > 0
      ? novel.characters.map(c => `${c.name}（${c.role}）：性格-${c.personality || '未设定'}；背景-${c.background || '未设定'}；目标-${c.goals || '未设定'}`).join('\n')
      : '暂无角色信息';
    
    // 完整的世界观设定
    const worldSettingsText = novel.worldSettings.length > 0
      ? novel.worldSettings.map(s => `${s.title}（${s.category}）：${s.description || ''}`).join('\n')
      : '暂无世界观设定';
    
    // 完整的简介和卷描述
    const synopsisText = novel.synopsis;
    const volumeSummaryText = volume.summary || '';
    const volumeOutlineText = volume.outline || '';
    
    const prompt = `请为小说《${novel.title}》创作下一章节的内容。

小说基本信息：
类型：${novel.genre}
简介：${synopsisText}

当前卷信息：
卷标题：${volume.title}
${volumeSummaryText ? `卷描述：${volumeSummaryText}` : ''}
${volumeOutlineText ? `卷大纲：${volumeOutlineText}` : ''}

前文内容（最近几章）：
${previousChapters || '（这是本卷的第一章）'}

当前章节信息：
章节标题：${currentChapter.title}
情节摘要：${currentChapter.summary || ''}
${currentChapter.aiPromptHints ? `写作提示：${currentChapter.aiPromptHints}` : ''}
${currentChapter.content ? `当前章节内容预览：${currentChapter.content.substring(0, 500)}${currentChapter.content.length > 500 ? '...' : ''}` : ''}

下一章节信息（需要生成的内容）：
章节标题：${nextChapter.title}
情节摘要：${nextChapter.summary || ''}
${nextChapter.aiPromptHints ? `写作提示：${nextChapter.aiPromptHints}` : ''}

角色信息：
${charactersText}

世界观设定：
${worldSettingsText}

要求：
1. 与前文内容保持连贯性和一致性
2. 遵循角色的性格设定和世界观规则
3. 按照下一章节的情节摘要推进故事
4. 保持高文学品质，使用沉浸式描述和引人入胜的对话
5. 注意情节的起承转合，为后续章节留下悬念
6. 仅输出章节正文内容，不要包含标题`;

    console.log('📝 提示词长度:', prompt.length);
    
    let responseText: string;
    if (onChunk) {
      // 流式传输模式
      onChunk('📝 正在生成下一章节内容...\n\n', false);
      responseText = await processStreamResponse(
        ai.models.generateContentStream({
          model: 'gemini-3-pro-preview',
          contents: prompt,
          config: {
            thinkingConfig: { thinkingBudget: 4000 }
          }
        }),
        (chunk, isComplete) => {
          if (!isComplete && chunk) {
            onChunk(chunk, false);
          }
        }
      );
    } else {
      // 非流式模式（向后兼容）
      const response = await withTimeout(ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: prompt,
        config: {
          thinkingConfig: { thinkingBudget: 4000 }
        }
      }));
      
      console.log('📝 API 响应状态:', response ? '成功' : '失败');
      
      if (!response || !response.text) {
        console.error('❌ API 返回空响应');
        throw new Error('API 返回空响应，可能是请求过大或网络超时');
      }
      
      responseText = response.text;
    }
    
    console.log('✅ 章节内容生成成功，长度:', responseText.length);
    return responseText;
  } catch (error: any) {
    console.error('生成下一章节内容 API 错误:', error);
    
    // 提供更详细的错误信息
    let errorMsg = '未知错误';
    if (error?.message) {
      errorMsg = error.message;
    } else if (typeof error === 'string') {
      errorMsg = error;
    } else if (error?.toString) {
      errorMsg = error.toString();
    }
    
    // 检查常见错误类型
    if (errorMsg.includes('Failed to fetch') || errorMsg.includes('fetch') || errorMsg.includes('ERR_CONNECTION_CLOSED') || errorMsg.includes('network')) {
      errorMsg = '网络连接失败。可能原因：\n1. 请求内容过大导致连接被关闭\n2. 网络连接不稳定\n3. 代理设置问题\n\n建议：\n1. 尝试简化当前章节内容\n2. 检查网络连接\n3. 稍后重试';
    } else if (errorMsg.includes('timeout') || errorMsg.includes('Timeout')) {
      errorMsg = '请求超时。可能是请求内容过大或网络较慢，请尝试：\n1. 简化当前章节内容\n2. 检查网络连接\n3. 稍后重试';
    } else if (errorMsg.includes('401') || errorMsg.includes('unauthorized') || errorMsg.includes('API key')) {
      errorMsg = 'API Key 无效或未配置。请检查 .env.local 文件中的 GEMINI_API_KEY';
    } else if (errorMsg.includes('403') || errorMsg.includes('forbidden')) {
      errorMsg = 'API 访问被拒绝。请检查 API Key 权限或配额';
    } else if (errorMsg.includes('429') || errorMsg.includes('rate limit') || errorMsg.includes('quota')) {
      errorMsg = 'API 请求频率过高或配额已用完。请稍后重试';
    }
    
    throw new Error(`生成下一章节内容失败: ${errorMsg}`);
  }
};

export const expandText = async (text: string, context: string) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  try {
    const response = await withTimeout(ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `请扩展以下文本，保持原有风格，并添加更多感官细节和角色内心想法。
      待扩展文本：${text}
      上下文：${context}`,
    }));
    
    if (!response || !response.text) {
      throw new Error('API 返回空响应');
    }
    
    return response.text;
  } catch (error: any) {
    console.error('扩展文本 API 错误:', error);
    throw new Error(`扩展文本失败: ${error?.message || error?.toString() || '未知错误'}`);
  }
};

export const polishText = async (text: string) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  try {
    const response = await withTimeout(ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `请润色以下文本，提升流畅度、词汇选择和情感共鸣。不要改变原意。
      待润色文本：${text}`,
    }));
    
    if (!response || !response.text) {
      throw new Error('API 返回空响应');
    }
    
    return response.text;
  } catch (error: any) {
    console.error('润色文本 API 错误:', error);
    throw new Error(`润色文本失败: ${error?.message || error?.toString() || '未知错误'}`);
  }
};

// 生成角色列表
export const generateCharacters = async (title: string, genre: string, synopsis: string, outline: string) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  try {
    console.log('🚀 开始生成角色列表...');
    const response = await withTimeout(ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `基于以下小说信息，生成主要角色列表（3-8个角色）：
      标题：${title}
      类型：${genre}
      简介：${synopsis}
      大纲：${outline.substring(0, 1000)}
      
      请为每个角色生成详细信息。仅返回 JSON 数组，每个对象包含以下键：
      - "name"（姓名）
      - "age"（年龄）
      - "role"（角色定位，如：主角、反派、配角等）
      - "personality"（性格特征）
      - "background"（背景故事）
      - "goals"（目标和动机）`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              age: { type: Type.STRING },
              role: { type: Type.STRING },
              personality: { type: Type.STRING },
              background: { type: Type.STRING },
              goals: { type: Type.STRING }
            },
            required: ["name", "age", "role", "personality", "background", "goals"]
          }
        }
      }
    }));
    
    if (!response || !response.text) {
      throw new Error('API 返回空响应');
    }
    
    const parsed = JSON.parse(response.text);
    if (!Array.isArray(parsed)) {
      throw new Error('返回的数据格式不正确');
    }
    
    console.log(`✅ 成功生成 ${parsed.length} 个角色`);
    return parsed;
  } catch (error: any) {
    console.error('生成角色 API 错误:', error);
    throw new Error(`生成角色失败: ${error?.message || error?.toString() || '未知错误'}`);
  }
};

// 生成世界观设定
export const generateWorldSettings = async (title: string, genre: string, synopsis: string, outline: string) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  try {
    console.log('🚀 开始生成世界观设定...');
    const response = await withTimeout(ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `基于以下小说信息，生成世界观设定列表（5-10个设定）：
      标题：${title}
      类型：${genre}
      简介：${synopsis}
      大纲：${outline.substring(0, 1000)}
      
      请为每个设定生成详细信息。仅返回 JSON 数组，每个对象包含以下键：
      - "title"（设定标题）
      - "category"（分类：地理、社会、魔法/科技、历史、其他）
      - "description"（详细描述）`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              category: { type: Type.STRING },
              description: { type: Type.STRING }
            },
            required: ["title", "category", "description"]
          }
        }
      }
    }));
    
    if (!response || !response.text) {
      throw new Error('API 返回空响应');
    }
    
    const parsed = JSON.parse(response.text);
    if (!Array.isArray(parsed)) {
      throw new Error('返回的数据格式不正确');
    }
    
    console.log(`✅ 成功生成 ${parsed.length} 个世界观设定`);
    return parsed;
  } catch (error: any) {
    console.error('生成世界观设定 API 错误:', error);
    throw new Error(`生成世界观设定失败: ${error?.message || error?.toString() || '未知错误'}`);
  }
};

// 生成时间线事件
export const generateTimelineEvents = async (title: string, genre: string, synopsis: string, outline: string) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  try {
    console.log('🚀 开始生成时间线事件...');
    const response = await withTimeout(ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `基于以下小说信息，生成重要时间线事件列表（5-10个事件）：
      标题：${title}
      类型：${genre}
      简介：${synopsis}
      大纲：${outline.substring(0, 1000)}
      
      请为每个事件生成详细信息。仅返回 JSON 数组，每个对象包含以下键：
      - "time"（时间/年代）
      - "event"（事件标题）
      - "impact"（事件影响和后果）`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              time: { type: Type.STRING },
              event: { type: Type.STRING },
              impact: { type: Type.STRING }
            },
            required: ["time", "event", "impact"]
          }
        }
      }
    }));
    
    if (!response || !response.text) {
      throw new Error('API 返回空响应');
    }
    
    const parsed = JSON.parse(response.text);
    if (!Array.isArray(parsed)) {
      throw new Error('返回的数据格式不正确');
    }
    
    console.log(`✅ 成功生成 ${parsed.length} 个时间线事件`);
    return parsed;
  } catch (error: any) {
    console.error('生成时间线事件 API 错误:', error);
    throw new Error(`生成时间线事件失败: ${error?.message || error?.toString() || '未知错误'}`);
  }
};

// 通过对话修改大纲并联动更新相关设定
export const modifyOutlineByDialogue = async (novel: Novel, userMessage: string, onChunk?: StreamChunkCallback) => {
  if (!apiKey) {
    throw new Error('未配置 Gemini API Key。请在 .env.local 文件中设置 GEMINI_API_KEY');
  }
  
  if (!novel.title || !novel.fullOutline) {
    throw new Error('需要完整的小说标题和大纲');
  }
  
  try {
    console.log('🚀 开始通过对话修改大纲...');
    
    // 限制输入长度以避免请求过大
    const maxOutlineLength = 1500;
    const maxCharacterLength = 500;
    const maxWorldLength = 500;
    const maxTimelineLength = 300;
    
    // 优化提示词长度
    const charactersText = novel.characters.length > 0 
      ? novel.characters.slice(0, 5).map(c => `${c.name}（${c.role}）：${c.personality?.substring(0, 50) || ''}`).join('；')
      : '暂无';
    
    const worldText = novel.worldSettings.length > 0
      ? novel.worldSettings.slice(0, 5).map(w => `${w.title}（${w.category}）`).join('；')
      : '暂无';
    
    const timelineText = novel.timeline.length > 0
      ? novel.timeline.slice(0, 5).map(t => `[${t.time}] ${t.event?.substring(0, 30) || ''}`).join('；')
      : '暂无';
    
    // 第一步：分析用户请求并生成修改后的大纲
    const modifyPrompt = `你是一名资深小说编辑，用户想要修改小说《${novel.title}》的大纲。

当前小说信息：
类型：${novel.genre}
简介：${novel.synopsis.substring(0, 200)}${novel.synopsis.length > 200 ? '...' : ''}
当前大纲：${novel.fullOutline.substring(0, maxOutlineLength)}${novel.fullOutline.length > maxOutlineLength ? '...' : ''}

当前卷结构：
${novel.volumes.map((v, idx) => `第${idx + 1}卷《${v.title}》：${v.summary || ''}${v.outline ? `\n卷大纲：${v.outline.substring(0, 200)}${v.outline.length > 200 ? '...' : ''}` : ''}`).join('\n\n') || '暂无卷结构'}

主要角色（前5个）：${charactersText}
世界观设定（前5个）：${worldText}
时间线事件（前5个）：${timelineText}

用户修改请求：${userMessage}

请根据用户的修改请求，生成修改后的完整大纲，保持原有风格和结构。如果用户的请求涉及以下内容，请一并提供更新：
1. 角色、世界观或时间线的修改
2. 卷结构的修改（卷的数量、标题、描述或卷大纲）
   - 如果用户要求增加卷，请在 volumes 数组中包含所有卷（包括新增的）
   - 如果用户要求删除卷，请在 volumes 数组中只包含要保留的卷
   - 如果用户要求修改卷的标题、描述或大纲，请在 volumes 数组中包含修改后的卷信息
   - 如果卷结构没有变化，可以不返回 volumes 字段

仅返回 JSON 对象，格式如下：
{
  "outline": "修改后的完整大纲文本（必须返回完整大纲）",
  "volumes": [可选，如果有卷结构改动，必须返回完整的卷数组，每个卷包含{"title": "卷标题", "summary": "卷描述", "outline": "卷详细大纲"}。如果用户要求增加或删除卷，请返回修改后的完整卷数组],
  "characters": [可选，如果有角色改动，包含{"name": "角色名", "role": "角色定位", "personality": "性格", "background": "背景", "goals": "目标"}],
  "worldSettings": [可选，如果有世界观改动，包含{"title": "设定标题", "category": "类别", "description": "描述"}],
  "timeline": [可选，如果有时间线改动，包含{"time": "时间", "event": "事件", "impact": "影响"}],
  "changes": ["变更说明1", "变更说明2"]
}`;
    
    console.log('📝 提示词长度:', modifyPrompt.length);
    console.log('📝 提示词预览:', modifyPrompt.substring(0, 500));
    
    let responseText: string;
    if (onChunk) {
      // 流式传输模式
      onChunk('🤖 正在分析你的修改请求并生成新的大纲...\n\n', false);
      responseText = await processStreamResponse(
        ai.models.generateContentStream({
          model: 'gemini-3-pro-preview',
          contents: modifyPrompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                outline: { type: Type.STRING },
                volumes: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      summary: { type: Type.STRING },
                      outline: { type: Type.STRING }
                    },
                    required: ["title"]
                  }
                },
                characters: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      role: { type: Type.STRING },
                      personality: { type: Type.STRING },
                      background: { type: Type.STRING },
                      goals: { type: Type.STRING }
                    },
                    required: ["name"]
                  }
                },
                worldSettings: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      category: { type: Type.STRING },
                      description: { type: Type.STRING }
                    },
                    required: ["title"]
                  }
                },
                timeline: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      time: { type: Type.STRING },
                      event: { type: Type.STRING },
                      impact: { type: Type.STRING }
                    },
                    required: ["time", "event"]
                  }
                },
                changes: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                }
              },
              required: ["outline"]
            },
            thinkingConfig: { thinkingBudget: 2000 }
          }
        }),
        (chunk, isComplete) => {
          if (!isComplete && chunk) {
            onChunk(chunk, false);
          }
        }
      );
    } else {
      // 非流式模式（向后兼容）
      const response = await withTimeout(ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: modifyPrompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              outline: { type: Type.STRING },
              volumes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    summary: { type: Type.STRING },
                    outline: { type: Type.STRING }
                  },
                  required: ["title"]
                }
              },
              characters: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    role: { type: Type.STRING },
                    personality: { type: Type.STRING },
                    background: { type: Type.STRING },
                    goals: { type: Type.STRING }
                  },
                  required: ["name"]
                }
              },
              worldSettings: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    category: { type: Type.STRING },
                    description: { type: Type.STRING }
                  },
                  required: ["title"]
                }
              },
              timeline: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    time: { type: Type.STRING },
                    event: { type: Type.STRING },
                    impact: { type: Type.STRING }
                  },
                  required: ["time", "event"]
                }
              },
              changes: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            },
            required: ["outline"]
          },
          thinkingConfig: { thinkingBudget: 2000 }
        }
      }));
      
      console.log('📝 API 响应状态:', response ? '成功' : '失败');
      
      if (!response || !response.text) {
        console.error('❌ API 返回空响应');
        throw new Error('API 返回空响应，可能是请求过大或网络超时。请尝试简化修改请求或检查网络连接');
      }
      
      responseText = response.text;
    }
    
    console.log('📝 响应文本长度:', responseText.length);
    console.log('📝 响应文本预览:', responseText.substring(0, 200));
    
    let result;
    try {
      result = JSON.parse(responseText);
      console.log('✅ JSON 解析成功');
    } catch (parseError: any) {
      console.error('❌ JSON 解析失败:', parseError);
      console.error('响应文本:', response.text.substring(0, 500));
      throw new Error(`API 返回的数据格式不正确，无法解析 JSON: ${parseError?.message || '未知错误'}`);
    }
    
    if (!result || typeof result !== 'object') {
      console.error('❌ 解析后的结果不是对象:', result);
      throw new Error('API 返回的数据格式不正确');
    }
    
    if (!result.outline || !result.outline.trim()) {
      console.error('❌ 生成的大纲为空');
      throw new Error('生成的大纲为空，请检查用户请求是否清晰');
    }
    
    console.log('✅ 大纲修改完成');
    console.log('📊 返回数据统计:', {
      outlineLength: result.outline.length,
      volumesCount: result.volumes?.length || 0,
      charactersCount: result.characters?.length || 0,
      worldSettingsCount: result.worldSettings?.length || 0,
      timelineCount: result.timeline?.length || 0,
      changesCount: result.changes?.length || 0
    });
    
    return {
      outline: result.outline,
      volumes: Array.isArray(result.volumes) ? result.volumes : [],
      characters: Array.isArray(result.characters) ? result.characters : [],
      worldSettings: Array.isArray(result.worldSettings) ? result.worldSettings : [],
      timeline: Array.isArray(result.timeline) ? result.timeline : [],
      changes: Array.isArray(result.changes) ? result.changes : []
    };
  } catch (error: any) {
    console.error('对话修改大纲 API 错误:', error);
    
    // 提供更详细的错误信息
    let errorMsg = '未知错误';
    if (error?.message) {
      errorMsg = error.message;
    } else if (typeof error === 'string') {
      errorMsg = error;
    } else if (error?.toString) {
      errorMsg = error.toString();
    }
    
    // 检查常见错误类型
    if (errorMsg.includes('Failed to fetch') || errorMsg.includes('fetch') || errorMsg.includes('network') || errorMsg.includes('NetworkError')) {
      errorMsg = '网络连接失败。请检查：\n1. 网络连接是否正常\n2. 代理软件（127.0.0.1:7899）是否正在运行\n3. 浏览器是否配置了系统代理或代理扩展\n4. 尝试刷新页面后重试';
    } else if (errorMsg.includes('401') || errorMsg.includes('unauthorized') || errorMsg.includes('API key')) {
      errorMsg = 'API Key 无效或未配置。请检查 .env.local 文件中的 GEMINI_API_KEY';
    } else if (errorMsg.includes('timeout') || errorMsg.includes('Timeout')) {
      errorMsg = '请求超时。可能是请求内容过大或网络较慢，请尝试：\n1. 简化修改请求\n2. 检查网络连接\n3. 稍后重试';
    } else if (errorMsg.includes('403') || errorMsg.includes('forbidden')) {
      errorMsg = 'API 访问被拒绝。请检查 API Key 权限或配额';
    } else if (errorMsg.includes('429') || errorMsg.includes('rate limit') || errorMsg.includes('quota')) {
      errorMsg = 'API 请求频率过高或配额已用完。请稍后重试';
    } else if (errorMsg.includes('JSON') || errorMsg.includes('parse')) {
      errorMsg = `数据解析失败: ${errorMsg}\n\n这可能是 API 返回了非 JSON 格式的数据。请查看浏览器控制台获取更多信息。`;
    }
    
    throw new Error(`修改大纲失败: ${errorMsg}`);
  }
};
