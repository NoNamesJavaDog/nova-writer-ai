
export interface Character {
  id: string;
  name: string;
  age: string;
  role: string;
  personality: string;
  background: string;
  goals: string;
}

export interface WorldSetting {
  id: string;
  title: string;
  description: string;
  category: '地理' | '社会' | '魔法/科技' | '历史' | '其他';
}

export interface TimelineEvent {
  id: string;
  time: string;
  event: string;
  impact: string;
}

export interface Chapter {
  id: string;
  title: string;
  summary: string;
  content: string;
  aiPromptHints: string;
  isGenerating?: boolean;
}

export interface Volume {
  id: string;
  title: string;
  summary?: string; // 卷的简要描述
  outline?: string; // 卷的详细大纲
  chapters: Chapter[];
}

export interface Novel {
  id: string;
  title: string;
  genre: string;
  synopsis: string;
  fullOutline: string;
  volumes: Volume[];
  characters: Character[];
  worldSettings: WorldSetting[];
  timeline: TimelineEvent[];
}

export type AppView = 'dashboard' | 'outline' | 'writing' | 'characters' | 'world' | 'timeline';

// 用户相关类型
export interface User {
  id: string;
  username: string;
  email: string;
  createdAt: number;
  lastLoginAt?: number;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}
