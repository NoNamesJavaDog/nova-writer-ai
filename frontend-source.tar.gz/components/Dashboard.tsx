
import React, { useState, useEffect, useRef } from 'react';
import { Novel, Character, WorldSetting, TimelineEvent, Volume } from '../types';
import { Sparkles, ArrowRight, Users, Globe, History } from 'lucide-react';
import { generateFullOutline, generateCharacters, generateWorldSettings, generateTimelineEvents } from '../services/geminiService';
import Console, { LogEntry } from './Console';

interface DashboardProps {
  novel: Novel;
  updateNovel: (updates: Partial<Novel>) => void;
  onStartWriting: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ novel, updateNovel, onStartWriting }) => {
  const [loading, setLoading] = useState(false);
  const [generateExtras, setGenerateExtras] = useState(true); // 默认开启生成额外内容
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [showConsole, setShowConsole] = useState(false);
  const [consoleMinimized, setConsoleMinimized] = useState(false);
  const isMountedRef = useRef(true);

  useEffect(() => {
    // 组件挂载时设置为 true
    isMountedRef.current = true;
    console.log('✅ Dashboard 组件已挂载');
    
    return () => {
      // 组件卸载时设置为 false
      isMountedRef.current = false;
      console.log('❌ Dashboard 组件已卸载');
    };
  }, []);

  // 添加日志
  const addLog = (type: LogEntry['type'], message: string) => {
    const logEntry: LogEntry = {
      id: `log-${Date.now()}-${Math.random()}`,
      timestamp: Date.now(),
      type,
      message
    };
    setLogs(prev => [...prev, logEntry]);
    // 同时输出到浏览器控制台
    const consoleMethod = type === 'error' ? 'error' : type === 'warning' ? 'warn' : 'log';
    console[consoleMethod](message);
  };

  // 追加流式内容到最后一个日志条目
  const appendStreamChunk = (chunk: string) => {
    if (!chunk) return;
    setLogs(prev => {
      const lastLog = prev[prev.length - 1];
      if (lastLog && lastLog.type === 'stream') {
        // 如果最后一条是流式日志，追加内容
        return [...prev.slice(0, -1), { ...lastLog, message: lastLog.message + chunk }];
      } else {
        // 否则创建新的流式日志条目
        const streamLog: LogEntry = {
          id: `stream-${Date.now()}-${Math.random()}`,
          timestamp: Date.now(),
          type: 'stream',
          message: chunk
        };
        return [...prev, streamLog];
      }
    });
  };

  // 清空日志
  const clearLogs = () => {
    setLogs([]);
  };

  const handleGenerateOutline = async () => {
    if (!novel.title || !novel.synopsis) {
      alert("请先提供标题和简介！");
      return;
    }
    
    if (!isMountedRef.current) return;
    setLoading(true);
    setShowConsole(true);
    setConsoleMinimized(false);
    clearLogs();
    
    try {
      // 1. 生成大纲和卷结构
      addLog('step', '📝 步骤 1/5: 生成完整大纲和卷结构...');
      addLog('info', `📖 小说标题: 《${novel.title}》`);
      addLog('info', `📚 类型: ${novel.genre}`);
      addLog('info', `💡 创意摘要: ${novel.synopsis.substring(0, 100)}${novel.synopsis.length > 100 ? '...' : ''}`);
      addLog('info', '🚀 开始调用 Gemini API...');
      
      // 显示提示词
      const outlinePrompt = `作为一名资深小说家，请为标题为《${novel.title}》的小说创作一份完整的故事大纲。
类型：${novel.genre}。
初始创意：${novel.synopsis}。
请提供多幕结构、关键情节转折，以及从开头到结尾的逻辑发展。`;
      addLog('info', '📋 提示词 (生成完整大纲):');
      addLog('info', '─'.repeat(60));
      outlinePrompt.split('\n').forEach(line => {
        addLog('info', `   ${line.trim()}`);
      });
      addLog('info', '─'.repeat(60));
      
      // 创建流式传输回调
      const onChunk = (chunk: string, isComplete: boolean) => {
        if (isComplete) {
          addLog('success', '\n✅ 生成完成！');
        } else if (chunk) {
          appendStreamChunk(chunk);
        }
      };
      
      const result = await generateFullOutline(novel.title, novel.genre, novel.synopsis, onChunk);
      if (!result.outline || !result.outline.trim()) {
        throw new Error("生成失败：返回的大纲为空");
      }
      
      addLog('success', '✅ 完整大纲生成成功！');
      addLog('info', `📄 大纲长度: ${result.outline.length} 字符`);
      
      // 显示生成卷结构的提示词
      if (result.outline) {
        const volumesPrompt = `基于以下完整大纲，将故事划分为多个卷（通常3-5卷）。
完整大纲：${result.outline.substring(0, 2000)}

请为每个卷生成标题和简要描述。仅返回 JSON 数组，每个对象包含：
- "title"（卷标题）
- "summary"（卷的简要描述，50-100字）`;
        addLog('info', '📋 提示词 (生成卷结构):');
        addLog('info', '─'.repeat(60));
        volumesPrompt.split('\n').forEach(line => {
          addLog('info', `   ${line.trim()}`);
        });
        addLog('info', '─'.repeat(60));
      }
      
      const updates: Partial<Novel> = { fullOutline: result.outline };
      
      // 处理卷结构
      if (result.volumes && Array.isArray(result.volumes) && result.volumes.length > 0) {
        const volumes: Volume[] = result.volumes.map((v: any, i: number) => ({
          id: `vol-${Date.now()}-${i}`,
          title: v.title || `第${i + 1}卷`,
          summary: v.summary || '',
          outline: '',
          chapters: []
        }));
        updates.volumes = volumes;
        addLog('success', `✅ 已生成 ${volumes.length} 个卷结构`);
        volumes.forEach((vol, idx) => {
          addLog('info', `   ${idx + 1}. ${vol.title}`);
        });
      } else {
        // 如果没有生成卷，创建默认卷
        if (!novel.volumes || novel.volumes.length === 0) {
          updates.volumes = [{ id: 'v1', title: '第一卷', chapters: [] }];
          addLog('warning', '⚠️ 未生成卷结构，使用默认卷');
        }
      }
      
      // 2. 如果启用，生成额外内容
      if (generateExtras) {
        try {
          // 生成角色
          addLog('step', '👥 步骤 2/5: 生成角色列表...');
          addLog('info', '🤔 AI 正在分析角色需求...');
          
          // 显示生成角色的提示词
          const charactersPrompt = `基于以下小说信息，生成主要角色列表（3-8个角色）：
标题：${novel.title}
类型：${novel.genre}
简介：${novel.synopsis}
大纲：${result.outline.substring(0, 1000)}

请为每个角色生成详细信息，仅返回 JSON 数组，每个对象包含：
- "name"（角色名称）
- "age"（年龄或年龄段）
- "role"（角色定位：主角、配角、反派等）
- "personality"（性格特点，50-100字）
- "background"（背景故事，100-200字）
- "goals"（角色目标或动机，50-100字）`;
          addLog('info', '📋 提示词 (生成角色):');
          addLog('info', '─'.repeat(60));
          charactersPrompt.split('\n').forEach(line => {
            addLog('info', `   ${line.trim()}`);
          });
          addLog('info', '─'.repeat(60));
          
          const charactersData = await generateCharacters(novel.title, novel.genre, novel.synopsis, result.outline);
          const characters: Character[] = charactersData.map((c: any, i: number) => ({
            id: `char-${Date.now()}-${i}`,
            name: c.name || `角色${i + 1}`,
            age: c.age || '',
            role: c.role || '配角',
            personality: c.personality || '',
            background: c.background || '',
            goals: c.goals || ''
          }));
          updates.characters = characters;
          addLog('success', `✅ 已生成 ${characters.length} 个角色`);
          characters.forEach((char, idx) => {
            addLog('info', `   ${idx + 1}. ${char.name} (${char.role})`);
          });
        } catch (err: any) {
          addLog('warning', `⚠️ 生成角色失败: ${err?.message || '未知错误'}，继续其他内容...`);
        }
        
        try {
          // 生成世界观
          addLog('step', '🌍 步骤 3/5: 生成世界观设定...');
          addLog('info', '🤔 AI 正在构建世界观体系...');
          
          // 显示生成世界观的提示词
          const worldPrompt = `基于以下小说信息，生成世界观设定列表（5-10个设定）：
标题：${novel.title}
类型：${novel.genre}
简介：${novel.synopsis}
大纲：${result.outline.substring(0, 1000)}

请涵盖以下类别（每个类别1-3个设定）：
- 地理：世界地图、主要地点、自然环境
- 社会：政治体系、社会结构、文化习俗
- 魔法/科技：魔法体系或科技水平、特殊规则
- 历史：重要历史事件、传说故事
- 其他：独特的设定元素

仅返回 JSON 数组，每个对象包含：
- "title"（设定标题）
- "category"（类别：地理、社会、魔法/科技、历史、其他）
- "description"（详细描述，100-200字）`;
          addLog('info', '📋 提示词 (生成世界观):');
          addLog('info', '─'.repeat(60));
          worldPrompt.split('\n').forEach(line => {
            addLog('info', `   ${line.trim()}`);
          });
          addLog('info', '─'.repeat(60));
          
          const worldData = await generateWorldSettings(novel.title, novel.genre, novel.synopsis, result.outline);
          const worldSettings: WorldSetting[] = worldData.map((w: any, i: number) => ({
            id: `world-${Date.now()}-${i}`,
            title: w.title || `设定${i + 1}`,
            category: (w.category === '地理' || w.category === '社会' || w.category === '魔法/科技' || w.category === '历史' || w.category === '其他') 
              ? w.category as WorldSetting['category']
              : '其他',
            description: w.description || ''
          }));
          updates.worldSettings = worldSettings;
          addLog('success', `✅ 已生成 ${worldSettings.length} 个世界观设定`);
          worldSettings.forEach((world, idx) => {
            addLog('info', `   ${idx + 1}. ${world.title} [${world.category}]`);
          });
        } catch (err: any) {
          addLog('warning', `⚠️ 生成世界观设定失败: ${err?.message || '未知错误'}，继续其他内容...`);
        }
        
        try {
          // 生成时间线
          addLog('step', '📅 步骤 4/5: 生成时间线事件...');
          addLog('info', '🤔 AI 正在梳理时间线...');
          
          // 显示生成时间线的提示词
          const timelinePrompt = `基于以下小说信息，生成重要时间线事件列表（5-10个事件）：
标题：${novel.title}
类型：${novel.genre}
简介：${novel.synopsis}
大纲：${result.outline.substring(0, 1000)}

请按时间顺序列出关键事件，包括：
- 故事开始前的背景事件
- 故事中的主要转折点
- 重要角色的关键时刻
- 影响剧情走向的重大事件

仅返回 JSON 数组，每个对象包含：
- "time"（时间点或时间段）
- "event"（事件描述，50-100字）
- "impact"（事件影响，50-100字）`;
          addLog('info', '📋 提示词 (生成时间线):');
          addLog('info', '─'.repeat(60));
          timelinePrompt.split('\n').forEach(line => {
            addLog('info', `   ${line.trim()}`);
          });
          addLog('info', '─'.repeat(60));
          
          const timelineData = await generateTimelineEvents(novel.title, novel.genre, novel.synopsis, result.outline);
          const timeline: TimelineEvent[] = timelineData.map((t: any, i: number) => ({
            id: `timeline-${Date.now()}-${i}`,
            time: t.time || '未知时间',
            event: t.event || `事件${i + 1}`,
            impact: t.impact || ''
          }));
          updates.timeline = timeline;
          addLog('success', `✅ 已生成 ${timeline.length} 个时间线事件`);
          timeline.slice(0, 5).forEach((event, idx) => {
            addLog('info', `   ${idx + 1}. [${event.time}] ${event.event}`);
          });
          if (timeline.length > 5) {
            addLog('info', `   ... 还有 ${timeline.length - 5} 个事件`);
          }
        } catch (err: any) {
          addLog('warning', `⚠️ 生成时间线事件失败: ${err?.message || '未知错误'}，继续...`);
        }
      }
      
      addLog('step', '🎨 步骤 5/5: 整合所有内容...');
      
      // 检查组件是否仍然挂载
      if (!isMountedRef.current) return;
      
      // 更新所有内容
      updateNovel(updates);
      addLog('success', '🎉 所有内容生成完成！');
      addLog('info', '✨ 准备跳转到大纲页面...');
      
      // 延迟跳转，确保状态更新完成
      setTimeout(() => {
        if (isMountedRef.current) {
          onStartWriting();
        }
      }, 1000);
    } catch (err: any) {
      if (!isMountedRef.current) return;
      
      addLog('error', `❌ 生成失败: ${err?.message || '未知错误'}`);
      const errorMessage = err?.message || err?.toString() || '未知错误';
      
      // 添加详细的错误信息到日志
      addLog('error', '可能的原因：');
      addLog('error', '1. API Key 未配置或无效');
      addLog('error', '2. 网络连接问题');
      addLog('error', '3. 查看控制台获取详细信息');
      addLog('error', `API Key 状态: ${process.env.API_KEY || process.env.GEMINI_API_KEY ? '已配置' : '未配置'}`);
      
      // 构建详细的错误提示
      let detailedMessage = `生成大纲失败：${errorMessage}\n\n`;
      detailedMessage += `可能的原因：\n`;
      detailedMessage += `1. API Key 未配置或无效\n`;
      detailedMessage += `   - 检查项目根目录是否有 .env.local 文件\n`;
      detailedMessage += `   - 确认文件中有：GEMINI_API_KEY=your_key\n`;
      detailedMessage += `   - 重启开发服务器（npm run dev）\n\n`;
      detailedMessage += `2. 网络连接问题\n`;
      detailedMessage += `   - 检查网络连接\n`;
      detailedMessage += `   - 如果使用代理，确保代理软件（127.0.0.1:7899）正在运行\n`;
      detailedMessage += `   - 浏览器可能需要配置系统代理\n\n`;
      detailedMessage += `3. 查看控制台获取详细错误信息\n\n`;
      detailedMessage += `当前 API Key 状态：${process.env.API_KEY || process.env.GEMINI_API_KEY ? '已配置' : '未配置'}`;
      
      alert(detailedMessage);
    } finally {
      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-6">
      <div className="mb-10 text-center">
        <h2 className="text-3xl font-bold text-slate-900 mb-2">欢迎回来，作者</h2>
        <p className="text-slate-500">让我们在 AI 的协助下创作您的下一部杰作。</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-xl border shadow-sm space-y-4">
          <h3 className="font-semibold text-lg text-slate-800">小说配置</h3>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">标题</label>
            <input 
              type="text" 
              value={novel.title}
              onChange={(e) => updateNovel({ title: e.target.value })}
              placeholder="永恒的回响"
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">类型</label>
            <select 
              value={novel.genre}
              onChange={(e) => updateNovel({ genre: e.target.value })}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            >
              <option>奇幻</option>
              <option>科幻</option>
              <option>悬疑</option>
              <option>言情</option>
              <option>惊悚</option>
              <option>历史</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">简介 / 核心创意</label>
            <textarea 
              value={novel.synopsis}
              onChange={(e) => updateNovel({ synopsis: e.target.value })}
              rows={4}
              placeholder="简要描述您的故事创意..."
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm"
            />
          </div>
          <div className="space-y-3">
            <div className="flex items-center gap-2 p-3 bg-slate-50 rounded-lg border">
              <input
                type="checkbox"
                id="generateExtras"
                checked={generateExtras}
                onChange={(e) => setGenerateExtras(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
              />
              <label htmlFor="generateExtras" className="text-sm text-slate-700 cursor-pointer flex-1">
                同时生成角色、世界观和时间线
              </label>
            </div>
            <button 
              onClick={handleGenerateOutline}
              disabled={loading}
              className="w-full py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 disabled:bg-slate-300 transition-all flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Sparkles size={18} className="animate-spin" />
                  {generateExtras ? '生成中（大纲+角色+世界观+时间线）...' : '生成大纲中...'}
                </>
              ) : (
                <>
                  <Sparkles size={18} />
                  {generateExtras ? '一键生成完整设定' : '生成完整大纲'}
                </>
              )}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border shadow-sm">
            <h3 className="font-semibold text-lg text-slate-800 mb-3">写作统计</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 rounded-lg border">
                <p className="text-xs text-slate-500 font-medium">章节</p>
                <p className="text-2xl font-bold text-slate-800">{novel.volumes.reduce((acc, v) => acc + v.chapters.length, 0)}</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-lg border">
                <p className="text-xs text-slate-500 font-medium">角色</p>
                <p className="text-2xl font-bold text-slate-800">{novel.characters.length}</p>
              </div>
            </div>
            <button 
              onClick={onStartWriting}
              className="w-full mt-6 py-3 border-2 border-slate-100 font-semibold rounded-lg hover:bg-slate-50 transition-all flex items-center justify-center gap-2 group"
            >
              跳转到编辑器 <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="bg-indigo-50 p-6 rounded-xl border border-indigo-100">
            <h4 className="font-semibold text-indigo-900 mb-2">专业提示</h4>
            <p className="text-sm text-indigo-700 leading-relaxed">
              在生成完整大纲之前，先定义您的主要角色和世界观规则。AI 将整合这些细节，创建更具个性化的故事结构！
            </p>
          </div>
        </div>
      </div>

      {/* 生成控制台 */}
      <Console
        logs={logs}
        showConsole={showConsole}
        consoleMinimized={consoleMinimized}
        onClose={() => setShowConsole(false)}
        onMinimize={setConsoleMinimized}
        onClear={clearLogs}
      />
    </div>
  );
};

export default Dashboard;
