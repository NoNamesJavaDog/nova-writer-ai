
import React from 'react';
import { AppView } from '../types';
import { 
  LayoutDashboard, 
  BookText, 
  PenTool, 
  Users, 
  Globe, 
  History,
  Settings
} from 'lucide-react';

interface SidebarProps {
  activeView: AppView;
  setActiveView: (view: AppView) => void;
  novelTitle: string;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, novelTitle }) => {
  const navItems = [
    { id: 'dashboard' as AppView, label: '仪表板', icon: LayoutDashboard },
    { id: 'outline' as AppView, label: '大纲', icon: BookText },
    { id: 'writing' as AppView, label: '写作', icon: PenTool },
    { id: 'characters' as AppView, label: '角色', icon: Users },
    { id: 'world' as AppView, label: '世界观', icon: Globe },
    { id: 'timeline' as AppView, label: '时间线', icon: History },
  ];

  return (
    <div className="w-64 bg-slate-900 text-slate-400 flex flex-col shrink-0">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-2 text-white mb-1">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-bold text-xl">N</div>
          <h1 className="text-lg font-bold tracking-tight">NovaWrite</h1>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              activeView === item.id 
                ? 'bg-slate-800 text-white shadow-sm' 
                : 'hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <item.icon size={18} />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium hover:bg-slate-800 hover:text-slate-200">
          <Settings size={18} />
          设置
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
